package triangle;

public class Tring {
    public static void main(String[] args) {
        for (int x=1;x<10;x++){
            for(int y=1;y<x;y++){
            System.out.print("*");
            }
            System.out.println();
        }
        System.out.println();
        for(int z=1;z<5;z++){
            for(int w=1;w<10;w++)
            {System.out.print("*");}
            System.out.println();
        }
        System.out.println();
        for (int l=10;l>1;l--){
            for(int m=1;m<l;m++){
            System.out.print("*");
            }
            System.out.println();
        }
    }

}
